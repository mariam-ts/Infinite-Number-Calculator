﻿// name: Mariam Tsirekidze
//redID: 823460489
//instr: prof. Tsintsadze
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace InfiniteNumOperations
{
    class Program
    {
        static void Main(string[] args)
        {
            //read from the file
            string text =File.ReadAllText(@"C:\Users\Asus\Downloads\infint.txt");
            string[] lines = File.ReadAllLines(@"C:\Users\Asus\Downloads\infint.txt");


            InfInt number1 = new InfInt();
            InfInt number2 = new InfInt();
       
            
             //calculate until the end of the file
             for (int i = 0; i < lines.Length; ++i)
             {
                 if(i%3 == 0)                            //first two strings are numbers
                 {
                     number1 = new InfInt(lines[i]);
                     Console.WriteLine(lines[i]);
                 }
                 else if(i%3 == 1)                        //first two strings are numbers
                {
                     number2 = new InfInt(lines[i]);
                     Console.WriteLine(lines[i]);
                 }
                 else                                     //third item is operator
                 {
                     if(lines[i] == "+")                //in case of +
                     {
                         if (number1.minus == false && number2.minus == false)

                         {
                             Console.WriteLine(lines[i]);
                             Console.WriteLine("=" + number1.Addition(number2)); //if both are positive just add
                             Console.WriteLine();
                         }
                         else if(number1.minus == true && number2.minus == false)
                         {
                             Console.WriteLine(lines[i]);
                             Console.WriteLine("=" + number2.Substraction(number1)); //if the first is negative, substract first from second
                             Console.WriteLine();
                         }
                         else if(number1.minus == false && number2.minus == true)
                         {
                             Console.WriteLine(lines[i]);
                             Console.WriteLine("=" + number1.Substraction(number2)); //if the second is negative, substract second from first
                            Console.WriteLine();
                         }
                         else if(number1.minus == true && number2.minus == true)
                         {
                             Console.WriteLine(lines[i]);
                             Console.WriteLine("=-" + number1.Addition(number2)); // if both are negative, add them and insert '-' in front
                             Console.WriteLine();
                         }
                     }
                     else if(lines[i] == "-")
                     {
                         if(number1.minus == false && number2.minus == false)     //if both are positive just substract second from first
                        {
                             Console.WriteLine(lines[i]);
                             Console.WriteLine("=" + number1.Substraction(number2)); 
                             Console.WriteLine();
                         }
                         else if(number1.minus == true && number2.minus == false)  //if the first is negative, add numbers and insert '-' in front
                        {
                             Console.WriteLine(lines[i]);
                             Console.WriteLine("=-" + number1.Addition(number2));
                             Console.WriteLine();
                         }
                         else if(number1.minus == false && number2.minus == true)  //if the second is negative, just add
                        {
                             Console.WriteLine(lines[i]);
                             Console.WriteLine("=" + number1.Addition(number2));
                             Console.WriteLine();
                         }
                         else if(number1.minus == true && number2.minus == true)  //if both are negative, substract first from second
                        {
                             Console.WriteLine(lines[i]);
                             Console.WriteLine("=" + number2.Substraction(number1));
                             Console.WriteLine();
                         }
                     }
                    else if (lines[i] == "*")
                    {
                        if (number1.minus == false && number2.minus == false)     //if both are positive just multiply
                        {
                            Console.WriteLine(lines[i]);
                            Console.Write("=" );
                            number2.Multiplication(number1).ForEach(Console.Write);
                            Console.WriteLine();
                        }
                        else if (number1.minus == true && number2.minus == false) //if first is negative, multiply and insert '-' in front
                        {
                            Console.WriteLine(lines[i]);
                            Console.Write("=-" );
                            number2.Multiplication(number1).ForEach(Console.Write);
                            Console.WriteLine();
                        }
                        else if (number1.minus == false && number2.minus == true)  //if second is negative, multiply and insert '-' in front
                        {
                            Console.WriteLine(lines[i]);
                            Console.Write("=-" );
                            number2.Multiplication(number1).ForEach(Console.Write);
                            Console.WriteLine();
                        }
                        else if (number1.minus == true && number2.minus == true) ////if both are negative, just multiply 
                        {
                            Console.WriteLine(lines[i]);
                            Console.Write("=");
                            number2.Multiplication(number1).ForEach(Console.Write);
                            Console.WriteLine();
                        }
                    }

                 }
                 






             }







        }
    }
}

